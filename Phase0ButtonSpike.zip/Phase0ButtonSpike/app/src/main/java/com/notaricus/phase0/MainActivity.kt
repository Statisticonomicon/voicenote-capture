package com.notaricus.phase0

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.KeyEvent
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 0 gating spike.
 *
 * Sole purpose: confirm that hardware button presses reach a foreground Wear app,
 * and reveal which KEYCODE_STEM_* maps to which physical button. Every key event
 * is shown on screen and written to Logcat (tag [TAG]); stem keys toggle a visible
 * IDLE/ACTIVE state and fire a distinct haptic. An on-screen button is provided as
 * a fallback control so the UI/haptic path can be verified independently of the
 * hardware keys.
 *
 * This is a prototype: it proves a mechanism, it is not production capture code.
 */
class MainActivity : Activity() {

    private companion object {
        const val TAG = "Phase0Spike"
    }

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var tapToggle: Button

    private var active = false
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.UK)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusView = findViewById(R.id.statusView)
        logView = findViewById(R.id.logView)
        logScroll = findViewById(R.id.logScroll)
        tapToggle = findViewById(R.id.tapToggle)

        tapToggle.setOnClickListener { toggle(source = "TAP (fallback button)") }

        renderStatus()
        appendLog("Started. Press the watch buttons, or inject keys via adb (see HOW_TO_RUN.md).")
    }

    /** Hardware key events arrive here while this Activity is the focused foreground window. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val name = KeyEvent.keyCodeToString(keyCode)
        appendLog("onKeyDown  code=$keyCode  name=$name")
        Log.d(TAG, "onKeyDown code=$keyCode name=$name")

        return when (keyCode) {
            KeyEvent.KEYCODE_STEM_PRIMARY,
            KeyEvent.KEYCODE_STEM_1,
            KeyEvent.KEYCODE_STEM_2,
            KeyEvent.KEYCODE_STEM_3 -> {
                toggle(source = "$name (code $keyCode)")
                true // consume the stem key
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    /** Logged for completeness; some buttons report more reliably on key-up. */
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        Log.d(TAG, "onKeyUp   code=$keyCode name=${KeyEvent.keyCodeToString(keyCode)}")
        return super.onKeyUp(keyCode, event)
    }

    private fun toggle(source: String) {
        active = !active
        renderStatus()
        vibrate(active)
        appendLog("TOGGLE -> ${if (active) "ACTIVE" else "IDLE"}   via $source")
    }

    private fun renderStatus() {
        statusView.text = if (active) "ACTIVE" else "IDLE"
        statusView.setBackgroundColor(if (active) 0xFF1B5E20.toInt() else 0xFF333333.toInt())
    }

    /** Distinct patterns: start = single short pulse, stop = double pulse. */
    private fun vibrate(active: Boolean) {
        val pattern = if (active) longArrayOf(0, 60) else longArrayOf(0, 40, 60, 40)
        val vibrator = obtainVibrator() ?: return
        try {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (t: Throwable) {
            Log.w(TAG, "Vibration failed (expected on emulators without a vibrator): ${t.message}")
        }
    }

    private fun obtainVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun appendLog(line: String) {
        logView.append("${timeFmt.format(Date())}  $line\n")
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
